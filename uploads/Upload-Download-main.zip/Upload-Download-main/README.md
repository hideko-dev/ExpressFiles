# Upload-Download
Upload and Download files using multer

This folder has two directories: client and server.
client directory contains the code for uploading an image file on front-end.
It is written in Vue.js while server directory makes use of multer library
to read files sent as multi-part form data by client
